import { render, screen } from "@testing-library/react";
import App from "../../App";

test('should initialize app state correctly', () => {
  render(<App />);
  
  expect(screen.getByRole('textbox')).toHaveValue(''); // Initial search term is empty
  expect(screen.queryByTestId('pokemon-data')).toBeNull(); // No pokemon data initially
});
