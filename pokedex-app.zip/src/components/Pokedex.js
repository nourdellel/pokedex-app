import React, { useEffect, useState } from 'react';
import './Pokedex.css';

const Pokedex = ({ onBack }) => {
  const [pokemonList, setPokemonList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [offset, setOffset] = useState(0);
  const [allFetched, setAllFetched] = useState(false);

  const fetchPokemonData = async () => {
    setLoading(true);
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=100&offset=${offset}`);
    const data = await response.json();

    const pokemonPromises = data.results.map(async (pokemon) => {
      const pokemonDetails = await fetch(pokemon.url);
      return pokemonDetails.json();
    });

    const pokemonData = await Promise.all(pokemonPromises);

    setPokemonList((prevData) => [...prevData, ...pokemonData]);
    setOffset(offset + 100); 
    setLoading(false);

    if (data.results.length < 100) {
      setAllFetched(true); 
    }
  };

  useEffect(() => {
    fetchPokemonData();
  }, []); 
  const loadMorePokemon = () => {
    if (!loading && !allFetched) {
      fetchPokemonData();
    }
  };

  if (loading && pokemonList.length === 0) {
    return <div className="loading">Loading Pokémon...</div>;
  }

  return (
    <div className="pokedex-container">
    <button className="pokedex-back-btn" onClick={onBack}></button>
      <h1 className="pokedex-title">Pokedex</h1>
      <div className="pokemon-grid">
        {pokemonList.map((pokemon) => (
          <div key={pokemon.id} className="pokemon-card">
            <img
              src={pokemon.sprites.front_default}
              alt={pokemon.name}
              className="pokemon-image-pokedex"
            />
            <h2 className="pokemon-name">{pokemon.name}</h2>
            <div className="type-container">
              {pokemon.types.map((type) => (
                <span key={type.type.name} className={`type-badge ${type.type.name}`}>
                  {type.type.name}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {!allFetched && (
        <button className="load-more" onClick={loadMorePokemon}>
          {loading ? 'Loading more...' : 'Load More'}
        </button>
      )}
    </div>
  );
};

export default Pokedex;
